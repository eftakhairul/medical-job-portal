<?php

$config['urls']['login']		= 'auth/login';
$config['urls']['logout'] 		= 'auth/logout';
$config['urls']['recoverPass']  = 'auth/recoverPassword/<code>';
