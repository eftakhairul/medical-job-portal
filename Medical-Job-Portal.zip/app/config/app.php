<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['site_title']   = 'Medical Job Portal'; //Site Title Goes Here
$config['site_main']    = ''; //Site Main Url Goes Here

$config['adminEmail']   = 'eftakhairul@gmail.com'; //Admin Email Address
$config['infoEmail']    = ''; // Info Email Address
$config['infoName']     = ''; // Info Name

$config['rowsPerPage'] = 20;
