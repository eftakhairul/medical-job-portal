<div class="block">

    <div class="block_head">
        <h2>Details</h2>
        
    </div> <!--.block_head ends -->
    
    <div class="block_content">

        <table cellpadding="0" cellspacing="0" width="100%">            
            
            <tbody>           
				<tr>
					<td>Total Jobs</td>
					<td class="centered"><?php echo $jobs ?></td>
				</tr>           
				<tr>
					<td>Total User</td>
					<td class="centered"><?php echo $users; ?></td>
				</tr>
				<tr>
					<td>Total Jobs Application</td>
					<td class="centered"><?php echo $applications; ?></td>
				</tr>
                
            </tbody>            
        </table>

    </div> <!--.block_content ends-->

</div> <!--.block ends-->
